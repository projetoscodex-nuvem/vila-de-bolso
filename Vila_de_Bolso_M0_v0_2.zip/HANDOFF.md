# Passagem de contexto

Data: 29/10/2026. Baseline ativa: **v0.2 — mapas grandes e navegáveis**. Atualizar ao final de cada tarefa.

## Identidade e requisito atual

Vila de Bolso — Meu Reino: puzzle 2D Android offline vertical. O proprietário confirmou que imaginou fase e reino maiores que a tela, navegáveis com um dedo e pinça. A versão v0.1 de mapas pequenos enquadrados está superada.

Parâmetros iniciais: fase 20 × 20, reino 40 × 60 de seis regiões 2 × 3, 60 colocações, 62 ofertas por fase, duas trocas e um desfazer. Números de protótipo ajustáveis com evidência. O mapa preserva as peças/posições reais de cada vila concluída. Não é city builder econômico.

Leia README.md, AGENTS.md, PROJECT_CONTEXT.md, PROJECT_STATE.md, MAP_AND_CAMERA.md e documentos relevantes. Referências em legacy_v0_1 valem para estilo, não layout/câmera atuais.

## Estado confirmado e relatado

Existem somente documentos e conceitos visuais. OWNER_REPORTED: repositório já criado, dois Markdown enviados à raiz, operação pelo celular. Não há URL/branch/commit auditados nem APK ou jogo comprovados. Esta revisão não executou implementação.

## Próxima ação

Enviar o ZIP v0.2 ao repositório e executar PROMPT_IMPORTACAO_CODEX.md. Reconciliar os arquivos antigos, preservar alterações do proprietário e apresentar commit/PR. Depois enviar PROMPT_M0_1_CODEX.md v0.2 para criar fundação, câmera e prova Android. Não executar implementação durante a tarefa de importação.

## Retorno mínimo

- URL/branch/commit ou PR e confirmação do que foi salvo no GitHub.
- Relatório de alterações/decisões e arquivos canônicos atuais.
- Resultados PASS/FAIL/NOT_RUN/BLOCKED com comandos e ambiente reais.
- APK/hash quando produzido e instrução de smoke físico incluindo pan/pinch.
- PROJECT_CONTEXT.md, PROJECT_STATE.md, DECISIONS.md e HANDOFF.md atualizados.

## Para um novo chat

“Continuar Vila de Bolso — Meu Reino, baseline v0.2. Leia os documentos atuais anexados e revise a entrega/commit. Android offline vertical; mapas grandes em fase e reino com arrasto e zoom; vilas preservadas por estado real. Não assumir sucesso do Codex nem inventar testes. Seguir o marco ativo e o padrão DECISÃO/IMPLEMENTAÇÃO/TESTE/VALIDADO/PENDÊNCIA/PRÓXIMO PASSO.”

## Ainda não comprovado

Engine/SDK/minSdk, aparelho, câmera real, conforto, metas, ritmo de 60 colocações, assets finais e desempenho. Esses itens não impedem importar documentação; impedem declarar o jogo validado.
