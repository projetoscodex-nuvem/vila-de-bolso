# Vila de Bolso — Meu Reino

Base documental v0.2 — 29/10/2026, America/Sao_Paulo.

Puzzle estratégico 2D, offline, vertical para Android. Cada fase constrói uma vila; o estado real da vila concluída passa a compor uma região fixa do reino. O jogador vê seu reino crescer sem perder as construções anteriores.

**Este pacote contém planejamento e referências, não o jogo implementado.** Não contém APK nem comprova configuração de ambiente ou teste Android. O proprietário relatou repositório já criado com dois Markdown; este pacote não o altera remotamente.

## Comece aqui

1. Leia [PROJECT_CONTEXT.md](PROJECT_CONTEXT.md), a memória de entrada.
2. Pelo celular, envie o ZIP v0.2 ao GitHub e execute [PROMPT_IMPORTACAO_CODEX.md](PROMPT_IMPORTACAO_CODEX.md); alternativamente envie o conteúdo extraído. Siga [GITHUB_CODEX_CLOUD_SETUP.md](GITHUB_CODEX_CLOUD_SETUP.md).
3. Após conferir a importação da baseline v0.2, envie [PROMPT_M0_1_CODEX.md](PROMPT_M0_1_CODEX.md) ao Codex com os documentos na raiz do repositório.
4. Após cada entrega, atualize [PROJECT_STATE.md](PROJECT_STATE.md) e [HANDOFF.md](HANDOFF.md).

## Fontes canônicas

| Arquivo | Responsabilidade |
| --- | --- |
| [AGENTS.md](AGENTS.md) | Instruções de trabalho do Codex |
| [PROJECT_CONTEXT.md](PROJECT_CONTEXT.md) | Identidade, contexto e decisões essenciais |
| [GAME_DESIGN.md](GAME_DESIGN.md) | Experiência e funcionalidades |
| [GAME_RULES.md](GAME_RULES.md) | Regras e parâmetros iniciais |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Estrutura técnica e persistência |
| [MAP_AND_CAMERA.md](MAP_AND_CAMERA.md) | Mapas grandes, câmera, arrasto, zoom e gestos |
| [ROADMAP.md](ROADMAP.md) | Marcos, limites e critérios de saída |
| [PROJECT_STATE.md](PROJECT_STATE.md) | Estado efetivamente comprovado |
| [DECISIONS.md](DECISIONS.md) | Decisões e mudanças de direção |
| [TEST_PLAN.md](TEST_PLAN.md) | Verificações técnicas e testes do proprietário |
| [ASSETS_AND_LICENSES.md](ASSETS_AND_LICENSES.md) | Arte, áudio, origem e licenças |
| [HANDOFF.md](HANDOFF.md) | Passagem de contexto ao próximo agente/chat |
| [SOURCES.md](SOURCES.md) | Documentação externa consultada |

As referências visuais estão em [references/README.md](references/README.md). São conceitos gerados por IA; não substituem especificações ou arquivos reais de assets.

## Escopo da primeira versão

Uma campanha de seis regiões em arranjo 2 × 3: cada fase tem 20 × 20 células e o reino composto tem 40 × 60 células. Ambos são maiores que o viewport no zoom de jogo e permitem arrasto com um dedo e pinça para zoom. Seis peças, 60 colocações iniciais por partida, pontuação por vizinhança, mapa persistente, modo livre isolado, tutorial, salvamento, configurações e créditos. Dimensões/quantidade de jogadas são parâmetros de protótipo; o requisito de navegar por câmera em mapas maiores que a tela é confirmado. Balanceamento e desempenho não foram testados.

## Fluxo de trabalho

ChatGPT: planejamento e revisão independente. Codex: engenharia e execução. Proprietário: operação, testes no Android e aceite. Uma etapa revisável por vez. A conclusão de um marco técnico não equivale a validar diversão ou concluir o jogo.

## Versão ativa e referências anteriores

Esta baseline v0.2 substitui a v0.1. O plano anterior de fase pequena inteiramente enquadrada foi superado pelo pedido do proprietário. Não executar prompts antigos nem misturar documentos de versões diferentes. Mockups anteriores ficam em references/legacy_v0_1 e servem somente para estilo/identidade. Este pacote não gera um repositório remoto nem atualiza os arquivos já enviados ao GitHub por conta própria.
