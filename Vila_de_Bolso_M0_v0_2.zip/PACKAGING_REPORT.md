# Verificação documental — pacote v0.2

Data: 29/10/2026 (America/Sao_Paulo).

- PASS: 21 Markdown lidos em UTF-8 e não vazios.
- PASS: links locais resolvem, inclusive quatro imagens em legacy_v0_1.
- PASS: ausência das instruções numéricas antigas de grade, jogadas e ofertas nos documentos operacionais. Referências à versão anterior permanecem apenas como histórico/superação.
- PASS: parâmetros consistentes: fase 20 × 20 = 400; seis regiões 2 × 3; reino 40 × 60 = 2.400; 60 colocações + duas trocas = 62 ofertas.
- PASS: câmera/arrasto/zoom e HUD fixa presentes na especificação e prompt M0.1.
- PASS: fluxo mobile ZIP → importação/reconciliação → implementação atualizado.
- PASS: estado registra os dois arquivos/repositório como OWNER_REPORTED, sem auditar GitHub.
- PASS: AGENTS.md abaixo de 32 KiB.
- PASS: manifesto regenerado, ZIP reaberto, CRC íntegro e hashes dos conteúdos conferidos após extração independente.
- NOT_RUN: engine, câmera/gestos, gameplay, exportação/instalação APK, persistência real, desempenho e balanceamento.

São verificações de documento e pacote. Os números são parâmetros iniciais, não medidas de diversão ou conforto validadas.
