# Histórico

## 0.2 — 29/10/2026

- Incorporado pedido do proprietário: mapas maiores que a tela nas fases e no reino, com arrasto/zoom.
- Parâmetros iniciais: fase 20 × 20, reino 40 × 60, 60 colocações, 62 ofertas e meta de 80–160 células construíveis por fase.
- Acrescentada especificação de câmera/gestos, HUD fixa, seleção segura, limites e persistência de posição/zoom.
- Atualizados arquitetura, regras, testes, roadmap, estado, memória documental e prompts; M0.1 agora exige navegação.
- Novo prompt de importação do ZIP pelo Codex, adequado ao envio pelo celular, preservando/reconciliando os dois Markdown já relatados na raiz.
- Mockups antigos reclassificados como LEGADO_VISUAL; não houve geração de mockups novos.
- Sem código de jogo, testes Android ou validação de equilíbrio nesta revisão.

## 0.1 — 29/10/2026

- Consolidada proposta Vila de Bolso — Meu Reino para Android offline vertical.
- Documentado reino persistente, regras iniciais, arquitetura, roteiro e validação.
- Preparados guia GitHub/Cloud, instruções AGENTS.md, memória documental e prompts.
- Selecionadas quatro referências visuais geradas na conversa.
- Sem código de jogo, APK, testes de runtime ou repositório remoto criado nesta preparação.
